<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Custom CSS-->
        <link rel="stylesheet"href="control.css">
        <link rel="stylesheet" href="css/bootstrap-reboot.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap-grid.min.css" type="text/css">

    </head>
    <body>
        <div class="pos-f-t">
            <div class="collapse" id="navbarToggleExternalContent">
                <div class="bg-dark p-4">
                    <h4 class="text-white">Collapsed content</h4>
                    <span class="text-muted">Toggleable via the navbar brand.</span>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg navbar-dark bg-info" id="nav-main">
                <a class="navbar-brand" href="img/logo.png"><img src="img/logo.png"alt="startup.logo" height="70"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="control.php">Control/Backlogs</a>
                        </li>

                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-warning my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </nav>


<header        <section id="control">
            <div class ="container">
                <div class="col-sm-10 col-sm-offset-1"></div>
                <h6 class="display-4">Components</h6>
            </div>
        </section>  
        </header>
        <main class="container">
                <div id="abc" class="row">

                    <article>
                        <h4>1. MSP 432P401R(CPU Card) </h4>
                        <figure class="image">
                            <img src="img/component1.jpg" alt="components1"/>  
                        </figure>
                        
                        <p> 
                            The SimpleLink™ MSP432P401R LaunchPad™ development kit enables you to develop high-performance applications that 
                            benefit from low-power operation. It features the MSP432P401R – which includes a 48MHz ARM® Cortex®-M4F, 
                            80uA/MHz active power and 660nA RTC operation, SAR Precision ADC with 16-bit performance and AES256 accelerator.
                            <br>
                            Parts given: <br>
                            1 x MSP-EXP432P401R LaunchPad Development Kit.<br>
                            1 x Micro-USB cable.
                             
                        </p>
                    </article><br>
                    <article>
                        <h4>2. Base and other components </h4>
                        <figure class="image">
                            <img src="img/component2_1.jpg" alt="components2"/>                           
                        </figure>
                        <p>
                            Base Components are: <br>
                            2 x Infrared Sensors <br>
                            1 x Ultrasonic Sensors <br>
                            1 x Battery holder compartment <br>
                            1 set of Rollers <br>
                            
                        </p>
                    </article><br>
        </div>
        </main>
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/bootsrap.min.js"></script>

    </body>


    <footer>
        <p><em>Copyright &copy; Robotic Coding Car Control 2021.</em></p>
    </footer>