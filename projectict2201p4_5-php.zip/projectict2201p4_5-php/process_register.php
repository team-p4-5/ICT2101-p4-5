<!doctype html>
<html lang="en">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

        <!-- Custom CSS-->
        <link rel="stylesheet"href="style.css">
        <link rel="stylesheet" href="css/bootstrap-reboot.css" type="text/css"/>
        <link rel="stylesheet" href="css/bootstrap-grid.min.css" type="text/css">


    </head>
    <body>                
        <div class="pos-f-t">
            <div class="collapse" id="navbarToggleExternalContent">
                <div class="bg-dark p-4">
                    <h4 class="text-white">Collapsed content</h4>
                    <span class="text-muted">Toggleable via the navbar brand.</span>
                </div>
            </div>
            <nav class="navbar navbar-expand-lg navbar-dark bg-info" id="nav-main">
                <a class="navbar-brand" href="img/logo.png"><img src="img/logo.png"alt="startup.logo" height="70"></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav mr-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                        </li>
                    </ul>
                    <form class="form-inline my-2 my-lg-0">
                        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                        <button class="btn btn-outline-warning my-2 my-sm-0" type="submit">Search</button>
                    </form>
                </div>
            </nav>


            <main class="container">
                <?php
                $fname = $lname = $email = $pwd_hashed = $errorMsg = "";
                $success = true;
                if ($_SERVER["REQUEST_METHOD"] == "POST") {


                    if (!empty($_POST["fname"])) {
                        $fname = sanitize_input($_POST["fname"]);
                    }
                    if (empty($_POST["lname"])) {
                        $errorMsg = "Last name is required.<br>";
                        $sucess = false;
                    } else {
                        $lname = sanitize_input($_POST["lname"]);
                    }
                    if (empty($_POST["email"])) {
                        $errorMsg .= "Email is required.<br>";
                        $success = false;
                    } else {
                        $email = sanitize_input($_POST["email"]);
// Additional check to make sure e-mail address is well-formed.
                        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                            $errorMsg .= "Invalid email format.";
                            $success = false;
                        }
                    }
                    if ($_POST["pwd"] != ($_POST["pwd_confirm"])) {
                        $errorMsg = "Password not the same with confirm password.Please check.";
                        $success = false;
                    } else {
                        $pwd_hashed = password_hash($_POST["pwd"], PASSWORD_DEFAULT);
                        $success = true;
                    }
                } else {
                    echo"<h2>You are authorise proceed.</h2>";
                    echo"<p>Please register at the link shown below:</p>";
                    echo"<button href='register.php'>Register...</button>";
                    exit();
                }
                if ($success) {
                    echo "<h4>Registration successful!</h4>";
                    echo "<p>Email: " . $email;
                } else {
                    echo "<h4>The following input errors were detected:</h4>";
                    echo "<p>" . $errorMsg . "</p>";
                }
                if ($success) {
                    saveMemberToDB();
                }

//Helper function that checks input for malicious or unwanted content.
                function sanitize_input($data) {
                    $data = trim($data);
                    $data = stripslashes($data);
                    $data = htmlspecialchars($data);
                    return $data;
                }

                if ($success) {
                    echo"<h2>Your register is successful.</h2>";
                    echo"<h4> Thank you for signing up.</h4> ";
                    echo"<a href='login.php' class='btn btn-success'>Log-in</button>";
                } else {
                    echo"<h2>Wait a minute!</h2>";
                    echo"<h4>The following errors were detected:</h4>";
                    echo"<p>" . $errorMsg . "</p>";
                    echo"<a href='register.php' class='btn btn-danger'>Return to Sign Up</a>";
                }
                /*
                 * Helper function to write the member data to the DB
                 */

                function saveMemberToDB() {
                    global $fname, $lname, $email, $pwd_hashed, $errorMsg, $success;
// Create database connection.
                    $config = parse_ini_file('../../private/db-config.ini');
                    $conn = new mysqli($config['servername'], $config['username'], $config['password'], $config['dbname']);

// Check connection
                    if ($conn->connect_error) {
                        $errorMsg = "Connection failed: " . $conn->connect_error;
                        $success = false;
                    } else {

// Prepare the statement:
                        $stmt = $conn->prepare("INSERT INTO World_of_pets_members (fname, lname, email, password) VALUES (?, ?, ?, ?)");
// Bind & execute the query statement:
                        $stmt->bind_param("ssss", $fname, $lname, $email, $pwd_hashed);
                        if (!$stmt->execute()) {
                            $errorMsg = "Execute failed: (" . $stmt->errno . ") " . $stmt->error;
                            $success = false;
                        }
                        $stmt->close();
                    }
                    $conn->close();
                }
                ?>
            </main>
            <!--Optional JavaScript-->
            <!--jQuery first, then Popper.js, then Bootstrap JS-->
            <script src = "js/bootsrap.min.js"></script>

    </body>

    <footer>
        <p><em>Copyright &copy; Robotic Coding Car Control 2021.</em></p>
    </footer>
</html>
